#include "stm32f10x.h"
#include "LED.h"

int main(void)
{
    LED_Init();//LED初始化(PB4)
    
    while(1)
    {
    }
}
